package com.example.demo.service;

import org.springframework.stereotype.Service;
import com.example.demo.model.Message;

@Service
public class GreetingService {

    public Message getMessage() {
        return new Message("Message from Service Layer!");
    }
}