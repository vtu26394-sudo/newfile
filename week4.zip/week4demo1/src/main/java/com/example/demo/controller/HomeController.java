package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.GreetingService;
import com.example.demo.model.Message;

@RestController
public class HomeController {

    @Autowired
    private GreetingService greetingService;

    @GetMapping("/")
    public String home() {
        return "Spring Boot is Working!";
    }

    @GetMapping("/service")
    public Message serviceMessage() {
        return greetingService.getMessage();
    }
}