package com.example.demo.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;

@Service
public class EmployeeService {

    public List<Employee> getAllEmployees() {
        return Arrays.asList(
            new Employee(101, "Clover"),
            new Employee(102, "Hasifa"),
            new Employee(103, "Alex")
        );
    }
}