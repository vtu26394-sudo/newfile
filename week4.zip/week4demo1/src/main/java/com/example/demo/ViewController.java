package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ViewController {

    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        // We are passing "paymentStatus" to the HTML
        model.addAttribute("paymentStatus", "Payment of ₹500 Processed Successfully");
        return "index"; 
    }
}