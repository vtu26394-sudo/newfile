package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service("mockPaymentService")
public class PaymentServiceMock implements PaymentService {

    @Override
    public String processPayment() {
        return "Mock Payment Processed!";
    }
}