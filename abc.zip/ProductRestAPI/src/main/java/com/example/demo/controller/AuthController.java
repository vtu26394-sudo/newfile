package com.example.demo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.demo.model.UserRegistrationDto;
import jakarta.validation.Valid;
import java.util.Map;

@RestController
public class AuthController {

    
    @PostMapping("/register")
    public ResponseEntity<String> register(@Valid @RequestBody UserRegistrationDto user) {
        return ResponseEntity.ok("User " + user.getName() + " registered successfully!");
    }

    
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Map<String, String> loginData) {
        if ("admin".equals(loginData.get("username")) && "password".equals(loginData.get("password"))) {
            return ResponseEntity.ok("DUMMY_JWT_TOKEN_ABC123");
        }
        return ResponseEntity.status(401).body("Invalid Credentials");
    }
}